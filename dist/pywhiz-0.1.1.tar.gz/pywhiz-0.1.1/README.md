# pywhiz ⚡

Python made fast, easy, and friendly!

A lightweight quality-of-life helper library for Python developers.

## Installation

```bash
pip install pywhiz
```
